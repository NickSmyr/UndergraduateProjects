x = [5,1,2]
a = [2,3]
print x + a
