def a(x):
    return 1

def b(x):
    return 2

d()

def c(x):
    return 2
