def add(x,y):
    return "hello world"
print add(2,1) + 2
