def add(a , b , c=1 , d=2):
    return a
def add(a , b , c, d, e,f =1 , g=2):
    return a
