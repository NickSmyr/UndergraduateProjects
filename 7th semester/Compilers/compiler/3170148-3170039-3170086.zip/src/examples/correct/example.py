#! /usr/bin/env python
#A miniPython example
def fib(n):    # write Fibonacci series up to n
               a = 0
               b = 1
               while true:
                        a = b
