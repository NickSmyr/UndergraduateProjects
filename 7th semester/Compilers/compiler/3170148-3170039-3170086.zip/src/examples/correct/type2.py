def a(x):
    return 1

def b(x):
    return 2

c(1)

def c(x):
    return 2
