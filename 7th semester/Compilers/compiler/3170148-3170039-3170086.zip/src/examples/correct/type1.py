def add(x,k):
    return x + k
print k
k=0
